import pygame
import random
import sys

# Initialize pygame
pygame.init()

# Screen dimensions
screen_width = 800
screen_height = 600

# Colors
black = (0, 0, 0)
white = (255, 255, 255)
blue = (0, 0, 255)

# Particle properties
particle_radius = 2
num_particles = 200
particles = []

# Initialize particles at the center
for _ in range(num_particles):
    particles.append([screen_width // 2, screen_height // 2])

# Create the screen object
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Diffusion Simulation: Random Walk")

# Clock object to control the frame rate
clock = pygame.time.Clock()

# Function to move particles
def move_particle(particle):
    direction = random.choice([(0, 1), (0, -1), (1, 0), (-1, 0)])
    particle[0] += direction[0]
    particle[1] += direction[1]

# Main loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Move all particles
    for particle in particles:
        move_particle(particle)

    # Clear the screen
    screen.fill(black)

    # Draw the particles
    for particle in particles:
        pygame.draw.circle(screen, blue, particle, particle_radius)

    # Update the display
    pygame.display.flip()

    # Control the frame rate
    clock.tick(60)
