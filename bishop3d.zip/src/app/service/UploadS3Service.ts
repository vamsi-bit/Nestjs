import { Injectable } from '@angular/core';
import { S3Client, PutObjectCommand, PutObjectCommandInput } from '@aws-sdk/client-s3';

@Injectable({
  providedIn: 'root',
})
export class UploadS3Service {

  private s3Client: S3Client;

  constructor() {
    this.s3Client = new S3Client({
      region: 'us-east-1', // Update with your region
      credentials: {
        accessKeyId: 'AKIASEJCI323IDYGJSH7', // Update with your access key ID
        secretAccessKey: '/tevc6+jjVjnNIFpixZVNhNNw2NeHOMT3XnMGYDL', // Update with your secret access key
      },
    });
  }

  async uploadFile(file: File, filePath: string): Promise<string> {
    try {
      const fileData = await this.readFile(file);
      const uploadParams: PutObjectCommandInput = {
        Bucket: 'bishop3d', // Update with your bucket name
        Key: filePath,
        Body: fileData,
        ContentType: file.type,
        ACL: 'public-read', // Corrected ACL type
      };

      const uploadCommand = new PutObjectCommand(uploadParams);
      const uploadResult = await this.s3Client.send(uploadCommand);
      https://bishop3d.s3.amazonaws.com/Chiropractor+LSO.png
      if (uploadResult && uploadResult.$metadata && uploadResult.$metadata.httpStatusCode === 200) {
        return `https://bishop3d.s3.amazonaws.com/${filePath}`; // Construct the URL based on your bucket and region
      } else {
        throw new Error('Failed to upload file to S3');
      }
    } catch (error) {
      throw error;
    }
  }

  private async readFile(file: File): Promise<Uint8Array> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (reader.result instanceof ArrayBuffer) {
          resolve(new Uint8Array(reader.result));
        } else {
          reject(new Error('Failed to read file'));
        }
      };
      reader.onerror = () => {
        reject(new Error('Failed to read file'));
      };
      reader.readAsArrayBuffer(file);
    });
  }
}
