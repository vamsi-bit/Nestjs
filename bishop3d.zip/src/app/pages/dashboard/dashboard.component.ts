import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
interface Order {
  OrderID: number;
  PatientInitial: string;
  PatientLastName: string;
  PatientDOB: string;
  SurgeryDate: string;
  BraceType: string;
  ProductName: string;
}
@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit {
  // private props
 

  // Constructor
  constructor(private router: Router,private http: HttpClient) {
  }

  products: any[] = [];
  orders: Order[] = [];

  
  viewProductform() {
    this.router.navigate(['/product/:id']);
  }
  viewProductDetails(product: any) {
    this.router.navigate(['/product', { product: JSON.stringify(product) }]);
  }
  viewOrderDetails(order: Order): void {
    this.router.navigate(['/order-details', { order: JSON.stringify(order) }]);
  }

  fetchProducts(): void {
    const apiUrl = 'https://300f5o6cf3.execute-api.us-east-1.amazonaws.com/dev/products';

    this.http.get(apiUrl).subscribe(
      (response: any) => {
        this.products = JSON.parse(response.body).products;
        console.log(this.products);
      },
      (error: any) => {
        console.error('Error fetching products:', error);
      }
    );
  }
  getOrders(): void {
    this.http.get<any>('https://300f5o6cf3.execute-api.us-east-1.amazonaws.com/dev/orders').subscribe(
      response => {
        this.orders = JSON.parse(response.body).orders;
      },
      error => {
        console.error('Error fetching orders:', error);
      }
    );
  }
  // Life cycle events
  ngOnInit(): void {
    this.getOrders();
    this.fetchProducts();
   
  }
  navigateToProductDetails(productId: string): void {
    // Navigate to the product details page with the provided product ID
    this.router.navigate(['/product', productId]);
  }

 
}