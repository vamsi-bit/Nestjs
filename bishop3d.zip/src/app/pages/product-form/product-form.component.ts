import { Component, ViewChild, ElementRef } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ProgressComponent } from '../progress/progress.component';
import { Product } from './product.interface';
import { UploadS3Service } from '../../service/UploadS3Service';
import { Router } from '@angular/router';
import { NgModule } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { NgxDropzoneComponent } from 'ngx-dropzone';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrl: './product-form.component.scss'
})
export class ProductFormComponent {
  product: Product = {
    ProductName: '',
    Description: '',
    Images: '',
    ExternalLinks: '',
    Indications: '',
    Advantages: ''
  };
  
  title = 's3-img-upload';
  files: File[] = [];

  renderImages: any = [];
  constructor(private http: HttpClient, private router:Router,private uploadS3Service: UploadS3Service,private toaster: ToastrService) {}

  onSelect(event: any) {
    this.files.push(...event.addedFiles);
  }

  onRemove(event: any) {
    this.files.splice(this.files.indexOf(event), 1);
  }

  async onImageUpdate() {
    console.log(this.files);
    if (this.files.length < 1) {
      this.toaster.error('Please Select Drop your Image first');
      return;
    }

    for (let i = 0; i < this.files.length; i += 1) {
      let file = this.files[i];

      let filePath =
        'images/' + Math.random() * 10000000000000000 + '_' + file.name; // to create unique name for avoiding being replaced
      try {
        let response = await this.uploadS3Service.uploadFile(file, filePath);
        console.log(response);

        this.toaster.success(file.name + 'uploaded Successfully :)');
        const url = (response as any).Location;
        this.renderImages.push(response);
        console.log(this.renderImages);
      } catch (error) {
        this.toaster.error('Something went wrong! ');
      }
    }
    this.files = [];
  }
  back(): void {
    this.router.navigate(['/dashboard']);
  }
  submitForm(): void {
    this.product.Images = this.renderImages.join(',');

    const requestBody = {
      body: this.product
    };
    this.http.post('https://300f5o6cf3.execute-api.us-east-1.amazonaws.com/dev/products/insert', requestBody)
      .subscribe(
        response => {
          console.log('Product saved successfully:', response);
          // Reset the form after successful submission
          window.alert('Product saved successfully!');
          this.resetForm();
        },
        error => {
          console.error('Error saving product:', error);
          // Handle error here
        }
      );
  }

  resetForm(): void {
    this.product = {
      ProductName: '',
      Description: '',
      Images: '',
      ExternalLinks: '',
      Indications: '',
      Advantages: ''
    };
  }

}
