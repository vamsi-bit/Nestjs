// product.interface.ts
export interface Product {
    ProductName: string;
    Description: string;
    Images: string;
    ExternalLinks: string;
    Indications: string;
    Advantages: string;
  }
  