import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

interface Order {
  OrderID: number;
  PatientInitial: string;
  PatientLastName: string;
  PatientDOB: string;
  SurgeryDate: string;
  BraceType: string;
  ProductName: string;
}

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.scss']
})
export class OrderDetailsComponent implements OnInit {
  order!: Order;

  constructor(private route: ActivatedRoute, private http: HttpClient, private router: Router) { }

  ngOnInit(): void {
    //this.getOrderDetails();
    this.route.params.subscribe(params => {
      if (params['order']) {
        this.order = JSON.parse(params['order']);
      } else {
        console.error('Order object parameter not found in route');
      }
    });
  }

  getOrderDetails(): void {
    const orderId = this.route.snapshot.paramMap.get('id');
    this.http.get<any>(`https://300f5o6cf3.execute-api.us-east-1.amazonaws.com/dev/orders/${orderId}`).subscribe(
      response => {
        this.order = JSON.parse(response.body).order;
      },
      error => {
        console.error('Error fetching order details:', error);
      }
    );
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }
}
