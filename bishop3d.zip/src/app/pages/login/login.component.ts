import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, HttpClientModule,CommonModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  loginObj: Login;
  signupObj: Signup;

  showLoginForm: boolean;

  constructor(private http: HttpClient, private router: Router) {
    this.loginObj = new Login();
    this.signupObj = new Signup();
    this.showLoginForm = true;
  }

  toggleForm() {
    this.showLoginForm = !this.showLoginForm;
  }
  onLogin() {
    this.http.post('https://300f5o6cf3.execute-api.us-east-1.amazonaws.com/dev/login', { body: this.loginObj }).subscribe((res: any) => {
      console.log('Login response:', res);
      if (res.statusCode === 200 && res.body && JSON.parse(res.body).message === 'Login successful!') {
        const role = JSON.parse(res.body).role;
        alert("Login Success");
        localStorage.setItem('angular17token', 'loggedin');
        localStorage.setItem('userRole', role);
        this.router.navigateByUrl('/dashboard');
      } else {
        alert("Login failed");
      }
    }, error => {
      console.error('Login error:', error);
    });
  }

  onSignup() {
    this.http.post('https://300f5o6cf3.execute-api.us-east-1.amazonaws.com/dev/signup', { body: this.signupObj }).subscribe((res: any) => {
      console.log('Signup response:', res);
      if (res.statusCode === 200 && res.body && JSON.parse(res.body).message === 'Signup successful!') {
        alert("Signup Success");
        this.router.navigateByUrl('/dashboard');
        this.toggleForm();
      } else {
        alert("Signup failed");
      }
    }, error => {
      console.error('Signup error:', error);
    });
  }
}

export class Login { 
  username: string;
  password: string;
  constructor() {
    this.username = '';
    this.password = '';
  } 
}

export class Signup { 
  username: string;
  password: string;
  email: string;
  mobile: string;
  constructor() {
    this.username = '';
    this.password = '';
    this.email = '';
    this.mobile = '';
  } 
}
