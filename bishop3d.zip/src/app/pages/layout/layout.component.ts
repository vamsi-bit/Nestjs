import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [RouterOutlet, CommonModule],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.css'
})
export class LayoutComponent {
  isLoggedIn: boolean;
  userRole: string | null;

  constructor(private router: Router) {
  this.isLoggedIn = localStorage.getItem('angular17token') === 'loggedin';
    this.userRole = localStorage.getItem('userRole');
  }

  logoff() {
    this.router.navigateByUrl('/login');
  }
  viewProductform() {
    this.router.navigate(['/product/:id']);
  }
  viewOrders() {
    this.router.navigate(['/orders']);
  }
}
