import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
//import { MatDialog } from '@angular/material/dialog';
//import { SuccessDialogComponent } from '../success-dialog/success-dialog.component';
import { HttpHeaders } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
interface Order {
  patientInitial: string;
  patientLastName: string;
  patientDOB: string;
  surgeryDate?: string;
  braceType: string;
  productID: string;
}

@Component({
  selector: 'app-order-form',
  templateUrl: './order-form.component.html',
  styleUrls: ['./order-form.component.scss']
})
export class OrderFormComponent {
  productId: string='';
  order: Order = {
    patientInitial: '',
    patientLastName: '',
    patientDOB: '',
    surgeryDate: '',
    braceType: '',
    productID: ''
  };

  constructor(
    private http: HttpClient,
    //private dialog: MatDialog,
    private route: ActivatedRoute,
    private router: Router
  ) {}
  back(): void {
    this.router.navigate(['/dashboard']);
  }
  ngOnInit(): void {
    // Subscribe to route params to get the product ID
    this.route.params.subscribe(params => {
      // Check if the 'id' parameter exists in the route
      if (params['id']) {
        // Get the product ID from the route params
        this.productId = params['id'];
        console.log('Product ID:', this.productId);
      } else {
        console.error('Product ID parameter not found in route');
      }
    });
  }
  submitForm(): void {
   // this.order.productID=this.productId
    // Set the headers including the Access-Control-Allow-Origin header
  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true', 
    })
  }
  const requestBody = {
    body: this.order
  };
    this.http.post('https://300f5o6cf3.execute-api.us-east-1.amazonaws.com/dev/orders/insert', requestBody,httpOptions)
      .subscribe(
        response => {
          console.log('Order saved successfully:', response);
         // this.openSuccessDialog();
          // Reset the form after successful submission
          window.alert('Your Order has been placed!');

          this.resetForm();
        },
        error => {
          console.error('Error saving order:', error);
          // Handle error here
        }
      );
  }

  resetForm(): void {
    this.order = {
      patientInitial: '',
      patientLastName: '',
      patientDOB: '',
      surgeryDate: '',
      braceType: '',
      productID: ''
    };
  }

 
}
