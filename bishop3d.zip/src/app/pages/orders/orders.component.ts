


import { Component, OnInit, ViewChild } from '@angular/core';


import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';


interface Order {
  OrderID: number;
  PatientInitial: string;
  PatientLastName: string;
  PatientDOB: string;
  SurgeryDate: string;
  BraceType: string;
  ProductName: string;
}

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrl: './orders.component.scss'
})
export class OrdersComponent implements OnInit{
  data:any;
  p: number = 1; // Current page number
  itemsPerPage: number = 2; // Items per page
  sortKey: string = ''; // Sort key
  sortDirection: string = 'asc'; // Sort direction


  // Constructor
  constructor(private router: Router,private http: HttpClient) {
    this.data = [
      {
        ProductId:'1' ,
        ImageUrl:'https://images.squarespace-cdn.com/content/v1/58c057bfc534a5a15e76f1a3/fdf6c4eb-c569-445e-b593-da72c5ae2b5a/Eric+Lunge+Color+White+Logo.jpeg?format=1500w',
        ProductName:'BISHOP KNEE BRACE',
        ProductDescription: 'PATIENT SHOULD BE AMBULATORY AND EXPERIENCING KNEE INSTABILITY DUE TO ONE OR MORE OF THE FOLLOWING:Ligament Injury, Meniscus, Injury Nerve Injury,Post-Operative Healing'
      },
      {
        ProductId:'2' ,
        ImageUrl:'https://images.squarespace-cdn.com/content/v1/58c057bfc534a5a15e76f1a3/b6fc9427-3a23-400d-9d96-81cac2825e1e/IMG_0795.JPG?format=1500w',
        ProductName:'LUMBAR BRACE',
        ProductDescription: 'PATIENT SHOULD BE AMBULATORY AND EXPERIENCING KNEE INSTABILITY DUE TO ONE OR MORE OF THE FOLLOWING:Ligament Injury, Meniscus, Injury Nerve Injury,Post-Operative Healing'
      }
    ];
  }

  orders: Order[] = [];

  

  
  viewOrderDetails(order: Order): void {
    this.router.navigate(['/order-details', { order: JSON.stringify(order) }]);
  }

  
  getOrders(): void {
    this.http.get<any>('https://300f5o6cf3.execute-api.us-east-1.amazonaws.com/dev/orders').subscribe(
      response => {
        this.orders = JSON.parse(response.body).orders;
      },
      error => {
        console.error('Error fetching orders:', error);
      }
    );
  }
  // Life cycle events
  ngOnInit(): void {
    this.getOrders();

  } 
  sort(key: keyof Order) {
    if (this.sortKey === key) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortKey = key;
      this.sortDirection = 'asc';
    }
    this.orders.sort((a, b) => {
      const aValue = a[key];
      const bValue = b[key];
      if (aValue < bValue) {
        return this.sortDirection === 'asc' ? -1 : 1;
      } else if (aValue > bValue) {
        return this.sortDirection === 'asc' ? 1 : -1;
      } else {
        return 0;
      }
    });
  }
 
}
