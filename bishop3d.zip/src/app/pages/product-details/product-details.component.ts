import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

interface Product {
  ProductId: string;
  ProductName: string;
  ProductDescription: string;
  Images: string[]; // Array of image URLs
  // Add more parameters as needed
}

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.scss']
})
export class ProductDetailsComponent implements OnInit {
  product: any;
  images: string[] = [];
  Description!:'';
  ExternalLinks!:[];
  sanitizedIndications!: SafeHtml;
  sanitizedAdvantages!:SafeHtml;
  constructor(private route: ActivatedRoute,private http: HttpClient,private sanitizer: DomSanitizer,private router: Router) { }
  products: any[] = [];
  currentImage: string | undefined;
  currentIndex = 0;

  

  

  
  ngOnInit(): void {
    
    this.route.params.subscribe(params => {
      // Check if the product parameter exists in the route
      if (params['product']) {
        // Get the product object from the route params and parse it from JSON
         this.product = JSON.parse(params['product']);
        this.images = this.product.Images.split(',');
        this.sanitizedIndications = this.sanitizer.bypassSecurityTrustHtml(this.product.Indications);
        this.sanitizedAdvantages = this.sanitizer.bypassSecurityTrustHtml(this.product.Advantages);
        this.ExternalLinks=this.product.ExternalLinks.split(',');
        this.Description=this.product.Description;
        this.currentImage = this.images.length > 0 ? this.images[0] : undefined;
        console.log(this.images);
        // Now you have access to the entire product object
        console.log('Product Details:', this.product);
      } else {
        console.error('Product object parameter not found in route');
      }
    });
    this.route.paramMap.subscribe(params => {
      // Assuming productId is passed as a route parameter
      const productId = params.get('id');
      // Assuming product details are fetched from a service based on productId
      //this.getProductDetails(productId);
    });
  }
  viewOrderDetails(): void {
    this.router.navigate(['/saveorder', { order:JSON.stringify(this.product.ProductId) }]);
  }

  

  nextImage(): void {
    if (this.currentIndex < this.images.length - 1) {
      this.currentIndex++;
      this.currentImage = this.images[this.currentIndex];
    }
  }

  prevImage(): void {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.currentImage = this.images[this.currentIndex];
    }
  }

  setCurrentImage(image: string): void {
    this.currentImage = image;
    this.currentIndex = this.images.indexOf(image);
  }
  
  downloadFile(): void {
    // Replace 'your-s3-file-link' with the actual S3 link of the file to download
    const s3FileLink = 'your-s3-file-link';
    // Create a temporary anchor element
    const anchor = document.createElement('a');
    anchor.style.display = 'none';
    anchor.href = s3FileLink;
    anchor.download = 'file-name'; // Specify the desired filename
    document.body.appendChild(anchor);
    // Trigger a click event on the anchor element to start the download
    anchor.click();
    // Remove the anchor element from the DOM
    document.body.removeChild(anchor);
  }


  
}
