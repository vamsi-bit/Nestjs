import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { ToastrModule } from 'ngx-toastr';
import { AppComponent } from './app.component';
import { ProductDetailsComponent } from './pages/product-details/product-details.component';
import { RouterModule, RouterOutlet } from '@angular/router';
//mport { DefaultComponent} from  './demo/default/default.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { OrderDetailsComponent } from './pages/order-details/order-details.component';
import { OrdersComponent } from './pages/orders/orders.component';
import { OrderFormComponent } from './pages/order-form/order-form.component';
import { AppRoutingModule } from './app.routes';
//import { SuccessDialogComponent } from './demo/success-dialog/success-dialog.component';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { ProductFormComponent } from './pages/product-form/product-form.component';
import { NgxPaginationModule } from 'ngx-pagination';
@NgModule({
  declarations: [
    AppComponent,
    ProductDetailsComponent,
    OrderDetailsComponent,
    OrdersComponent,
    OrderFormComponent,
    ProductFormComponent
  ],
  imports: [BrowserModule,NgxPaginationModule, AppRoutingModule,  ToastrModule.forRoot(),NgxDropzoneModule, BrowserAnimationsModule, HttpClientModule, ReactiveFormsModule,FormsModule,RouterModule ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
