import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { LayoutComponent } from './pages/layout/layout.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { authGuard } from './service/auth.guard';
import { ProductDetailsComponent } from './pages/product-details/product-details.component';
import { ProductFormComponent } from './pages/product-form/product-form.component';
import { OrdersComponent } from './pages/orders/orders.component';
import { OrderDetailsComponent } from './pages/order-details/order-details.component';
import { OrderFormComponent } from './pages/order-form/order-form.component';

export const routes: Routes = [
    {
        path: '', redirectTo:'login' , pathMatch:'full'
    },
    {
        path:'login',
        component:LoginComponent
    },
    {
        path:'',
        component:LayoutComponent,
        children:[
            {
                path:'dashboard',
                component:DashboardComponent,
                canActivate: [authGuard]
            },
            {   path: 'product', 
                component: ProductDetailsComponent,
                canActivate: [authGuard] 
            },
            {   path: 'product/:id', 
                component: ProductFormComponent,
                canActivate: [authGuard] 
            },
            
            {   path: 'orders', 
                component: OrdersComponent,
                canActivate: [authGuard]
             } ,
            {   path: 'order-details',
                component: OrderDetailsComponent, 
                canActivate: [authGuard]
            },
      
            {   path: 'saveorder', 
                component: OrderFormComponent,
                canActivate: [authGuard]
            }   
        ]
    }
];
@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
export class AppRoutingModule {}
  